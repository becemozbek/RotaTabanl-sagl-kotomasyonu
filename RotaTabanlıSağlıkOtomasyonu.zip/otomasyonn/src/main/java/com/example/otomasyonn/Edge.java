package com.example.otomasyonn;

/**
 * Graf kenarı: iki Node arası mesafe ve trafik yoğunluğu
 * Özel yol türleri için ek özellikler içerir
 */
public class Edge {
    private final Node from;
    private final Node to;
    private final double distance;
    private final double congestion;
    private final String roadType; // "highway", "street", "path"

    public Edge(Node from, Node to, double distance, double congestion) {
        this(from, to, distance, congestion, "street");
    }

    public Edge(Node from, Node to, double distance, double congestion, String roadType) {
        this.from = from;
        this.to = to;
        this.distance = distance;
        this.congestion = congestion;
        this.roadType = roadType;
    }

    /** Toplam ağırlık = mesafe × trafik katsayısı × yol tipi */
    public double getWeight() {
        double roadFactor = switch (roadType) {
            case "highway" -> 0.7; // Otoyol daha hızlı
            case "street" -> 1.0;  // Normal cadde
            case "path" -> 1.3;    // Dar yol daha yavaş
            default -> 1.0;
        };
        return distance * congestion * roadFactor;
    }

    public Node getFrom() { return from; }
    public Node getTo()   { return to;   }
    public double getDistance()   { return distance;   }
    public double getCongestion() { return congestion; }
    public String getRoadType() { return roadType; }
}