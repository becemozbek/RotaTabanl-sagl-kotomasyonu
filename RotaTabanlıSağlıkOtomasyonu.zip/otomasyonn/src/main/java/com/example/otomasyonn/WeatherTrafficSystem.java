package com.example.otomasyonn;

import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.*;

/**
 * Hava durumu ve trafik yoğunluğu simülasyon sistemi
 * Ambulans rotalarını ve süreleri etkiler
 */
public class WeatherTrafficSystem {

    private WeatherCondition currentWeather;
    private final Map<String, Double> roadTrafficLevels;
    private final Random random;
    private LocalDateTime lastUpdate;

    public enum WeatherCondition {
        SUNNY("☀️ Güneşli", 1.0, "İdeal sürüş koşulları"),
        CLOUDY("☁️ Bulutlu", 1.1, "Normal sürüş koşulları"),
        RAINY("🌧️ Yağmurlu", 1.4, "Kaygan yollar, dikkatli sürüş"),
        HEAVY_RAIN("⛈️ Sağanak", 1.7, "Görüş mesafesi düşük, yavaş sürüş"),
        SNOWY("❄️ Karlı", 1.8, "Buzlu yollar, çok dikkatli sürüş"),
        FOGGY("🌫️ Sisli", 1.5, "Görüş mesafesi çok düşük"),
        STORMY("⛈️ Fırtınalı", 2.0, "Tehlikeli hava koşulları");

        private final String display;
        private final double speedMultiplier;
        private final String description;

        WeatherCondition(String display, double speedMultiplier, String description) {
            this.display = display;
            this.speedMultiplier = speedMultiplier;
            this.description = description;
        }

        public String getDisplay() { return display; }
        public double getSpeedMultiplier() { return speedMultiplier; }
        public String getDescription() { return description; }
    }

    public enum RoadType {
        HIGHWAY("Otoyol"),
        MAIN_STREET("Ana Cadde"),
        SIDE_STREET("Yan Sokak"),
        RESIDENTIAL("Mahalle İçi");

        private final String display;
        RoadType(String display) { this.display = display; }
        public String getDisplay() { return display; }
    }

    public WeatherTrafficSystem() {
        this.random = new Random();
        this.roadTrafficLevels = new HashMap<>();
        this.lastUpdate = LocalDateTime.now();

        initializeTrafficLevels();
        generateRandomWeather();
    }

    private void initializeTrafficLevels() {
        // Ana yollar
        roadTrafficLevels.put("Eskişehir Yolu", 1.2);
        roadTrafficLevels.put("Konya Yolu", 1.1);
        roadTrafficLevels.put("İstanbul Yolu", 1.4);
        roadTrafficLevels.put("Kızılay Meydanı", 1.8);

        // Hastane çevresi
        roadTrafficLevels.put("Hacettepe Çevresi", 1.5);
        roadTrafficLevels.put("Şehir Hastanesi Yolu", 1.3);
        roadTrafficLevels.put("Gülhane Çevresi", 1.2);

        // Mahalle yolları
        roadTrafficLevels.put("Çankaya İçi", 1.1);
        roadTrafficLevels.put("Keçiören İçi", 1.0);
        roadTrafficLevels.put("Etimesgut İçi", 0.9);
    }

    private void generateRandomWeather() {
        WeatherCondition[] conditions = WeatherCondition.values();

        // Mevsimsel ağırlıklar (şu an için basit random)
        int month = LocalDateTime.now().getMonthValue();

        if (month >= 12 || month <= 2) { // Kış
            currentWeather = random.nextDouble() < 0.3 ? WeatherCondition.SNOWY :
                    random.nextDouble() < 0.5 ? WeatherCondition.RAINY :
                            random.nextDouble() < 0.7 ? WeatherCondition.CLOUDY : WeatherCondition.SUNNY;
        } else if (month >= 6 && month <= 8) { // Yaz
            currentWeather = random.nextDouble() < 0.6 ? WeatherCondition.SUNNY :
                    random.nextDouble() < 0.8 ? WeatherCondition.CLOUDY : WeatherCondition.RAINY;
        } else { // İlkbahar/Sonbahar
            currentWeather = conditions[random.nextInt(conditions.length)];
        }
    }

    /**
     * Günün saatine göre dinamik trafik yoğunluğu hesapla
     */
    public double calculateTrafficMultiplier() {
        LocalTime now = LocalTime.now();
        int hour = now.getHour();

        // Sabah ve akşam yoğunluk saatleri
        if ((hour >= 7 && hour <= 9) || (hour >= 17 && hour <= 19)) {
            return 1.8 + random.nextDouble() * 0.4; // 1.8-2.2x yavaşlama
        }
        // Öğle saatleri
        else if (hour >= 12 && hour <= 14) {
            return 1.3 + random.nextDouble() * 0.3; // 1.3-1.6x yavaşlama
        }
        // Gece saatleri
        else if (hour >= 22 || hour <= 6) {
            return 0.8 + random.nextDouble() * 0.2; // 0.8-1.0x (daha hızlı)
        }
        // Normal saatler
        else {
            return 1.0 + random.nextDouble() * 0.3; // 1.0-1.3x
        }
    }

    /**
     * Belirli bir yol segmenti için toplam seyahat süresini hesapla
     */
    public double calculateTravelTime(String roadName, double baseDistance, RoadType roadType) {
        double weatherMultiplier = currentWeather.getSpeedMultiplier();
        double trafficMultiplier = calculateTrafficMultiplier();
        double roadSpecificMultiplier = roadTrafficLevels.getOrDefault(roadName, 1.0);

        // Yol tipine göre temel süre ayarı
        double roadTypeMultiplier = switch (roadType) {
            case HIGHWAY -> 0.7;        // Otoyol daha hızlı
            case MAIN_STREET -> 1.0;    // Ana cadde normal
            case SIDE_STREET -> 1.3;    // Yan sokak yavaş
            case RESIDENTIAL -> 1.1;    // Mahalle içi biraz yavaş
        };

        return baseDistance * weatherMultiplier * trafficMultiplier *
                roadSpecificMultiplier * roadTypeMultiplier;
    }

    /**
     * Sistemde güncelleme yap (her 5 dakikada bir çağrılabilir)
     */
    public void updateSystem() {
        LocalDateTime now = LocalDateTime.now();

        // Hava durumu güncelleme (her saat %10 olasılık)
        if (random.nextDouble() < 0.1) {
            generateRandomWeather();
        }

        // Trafik durumlarını güncelle
        updateTrafficLevels();

        lastUpdate = now;
    }

    private void updateTrafficLevels() {
        // Rastgele trafik değişiklikleri
        for (String road : roadTrafficLevels.keySet()) {
            double currentLevel = roadTrafficLevels.get(road);
            double change = (random.nextDouble() - 0.5) * 0.2; // ±0.1 değişim
            double newLevel = Math.max(0.5, Math.min(2.5, currentLevel + change));
            roadTrafficLevels.put(road, newLevel);
        }
    }

    /**
     * Acil durum için en uygun rotayı öner
     */
    public String recommendRoute(String startLocation, String endLocation) {
        StringBuilder recommendation = new StringBuilder();

        recommendation.append("🛣️ ROTA ÖNERİLERİ:\n\n");
        recommendation.append("Mevcut Hava: ").append(currentWeather.getDisplay()).append("\n");
        recommendation.append("Açıklama: ").append(currentWeather.getDescription()).append("\n\n");

        // Trafik durumu analizi
        double currentTraffic = calculateTrafficMultiplier();
        String trafficStatus = currentTraffic > 1.5 ? "🟥 Yoğun" :
                currentTraffic > 1.2 ? "🟨 Orta" : "🟢 Açık";

        recommendation.append("Trafik Durumu: ").append(trafficStatus).append("\n");
        recommendation.append("Tahmini Gecikme: %").append(String.format("%.0f", (currentTraffic - 1) * 100)).append("\n\n");

        // Yol önerileri
        if (currentWeather == WeatherCondition.SNOWY || currentWeather == WeatherCondition.STORMY) {
            recommendation.append("⚠️ Ana yolları tercih edin\n");
            recommendation.append("🐌 Hız limitinin altında sürün\n");
        } else if (currentTraffic > 1.5) {
            recommendation.append("🚦 Alternatif güzergahları deneyin\n");
            recommendation.append("📡 Trafik durumunu takip edin\n");
        } else {
            recommendation.append("✅ Normal rota kullanılabilir\n");
        }

        return recommendation.toString();
    }

    /**
     * Hava durumu raporu al
     */
    public String getWeatherReport() {
        return String.format("%s\n%s\nSon Güncelleme: %s",
                currentWeather.getDisplay(),
                currentWeather.getDescription(),
                lastUpdate.toLocalTime().toString().substring(0, 5));
    }

    /**
     * Detaylı trafik raporu
     */
    public String getTrafficReport() {
        StringBuilder report = new StringBuilder();
        report.append("🚦 TRAFİK DURUMU RAPORU\n\n");

        roadTrafficLevels.entrySet().stream()
                .sorted(Map.Entry.<String, Double>comparingByValue().reversed())
                .forEach(entry -> {
                    String road = entry.getKey();
                    Double level = entry.getValue();
                    String status = level > 1.5 ? "🟥" : level > 1.2 ? "🟨" : "🟢";
                    report.append(String.format("%s %s: %.1fx\n", status, road, level));
                });

        return report.toString();
    }

    // Getters
    public WeatherCondition getCurrentWeather() { return currentWeather; }
    public Map<String, Double> getRoadTrafficLevels() { return new HashMap<>(roadTrafficLevels); }
    public LocalDateTime getLastUpdate() { return lastUpdate; }

    /**
     * Test için hava durumunu manuel set et
     */
    public void setWeatherForTesting(WeatherCondition weather) {
        this.currentWeather = weather;
    }
}