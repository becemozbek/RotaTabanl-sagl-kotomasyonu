package com.example.otomasyonn;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

/**
 * Hasta kayıt sistemi - tıbbi geçmiş ve acil müdahale bilgileri
 */
public class PatientRecord {
    private final String patientId;
    private final String fullName;
    private final int age;
    private final String bloodType;
    private final String gender;
    private final String phoneNumber;
    private final String address;

    private final List<MedicalHistory> medicalHistory;
    private final List<EmergencyCall> emergencyCalls;
    private final Set<String> allergies;
    private final Set<String> medications;

    public enum BloodType {
        A_POSITIVE("A+"), A_NEGATIVE("A-"),
        B_POSITIVE("B+"), B_NEGATIVE("B-"),
        AB_POSITIVE("AB+"), AB_NEGATIVE("AB-"),
        O_POSITIVE("O+"), O_NEGATIVE("O-");

        private final String display;
        BloodType(String display) { this.display = display; }
        public String getDisplay() { return display; }
    }

    public enum Priority {
        CRITICAL("🔴 KRİTİK", 1),
        HIGH("🟠 YÜKSEK", 2),
        MEDIUM("🟡 ORTA", 3),
        LOW("🟢 DÜŞÜK", 4);

        private final String display;
        private final int level;

        Priority(String display, int level) {
            this.display = display;
            this.level = level;
        }

        public String getDisplay() { return display; }
        public int getLevel() { return level; }
    }

    public PatientRecord(String patientId, String fullName, int age, String bloodType, String gender) {
        this.patientId = patientId;
        this.fullName = fullName;
        this.age = age;
        this.bloodType = bloodType;
        this.gender = gender;
        this.phoneNumber = generatePhoneNumber();
        this.address = generateAddress();

        this.medicalHistory = new ArrayList<>();
        this.emergencyCalls = new ArrayList<>();
        this.allergies = new HashSet<>();
        this.medications = new HashSet<>();

        generateRandomMedicalData();
    }

    private String generatePhoneNumber() {
        Random random = new Random();
        // İstanbul telefon kodları: 212 (Avrupa) ve 216 (Anadolu)
        String[] areaCodes = {"212", "216"};
        String areaCode = areaCodes[random.nextInt(areaCodes.length)];

        return String.format("0%s %d%d%d %d%d %d%d",
                areaCode,
                random.nextInt(10), random.nextInt(10), random.nextInt(10),
                random.nextInt(10), random.nextInt(10),
                random.nextInt(10), random.nextInt(10));
    }

    private String generateAddress() {
        // İSTANBUL MAHALLE VE SOKAKLAR
        String[] streets = {"Vatan Caddesi", "Millet Caddesi", "Adnan Menderes Bulvarı",
                "Fevzi Paşa Caddesi", "Turgut Özal Millet Caddesi", "Kennedy Caddesi",
                "Şair Nedim Caddesi", "Ordu Caddesi"};

        String[] districts = {"Fatih", "Beyoğlu", "Şişli", "Kadıköy", "Üsküdar", "Beşiktaş",
                "Bakırköy", "Zeytinburnu", "Eminönü", "Çapa", "Cevizlibağ"};

        Random random = new Random();
        return String.format("%s No:%d, %s/İSTANBUL",
                streets[random.nextInt(streets.length)],
                1 + random.nextInt(150),
                districts[random.nextInt(districts.length)]);
    }

    private void generateRandomMedicalData() {
        Random random = new Random();

        // Rastgele alerjiler ekle
        String[] commonAllergies = {"Penisilin", "Aspirin", "Polen", "Fındık", "Yumurta", "Süt", "Balık", "Kedi Tüyü"};
        for (String allergy : commonAllergies) {
            if (random.nextDouble() < 0.15) { // %15 olasılık
                allergies.add(allergy);
            }
        }

        // Rastgele ilaçlar ekle
        String[] commonMedications = {"Tansiyon İlacı", "Diyabet İlacı", "Kalp İlacı", "Vitamin D", "B12", "Tiroid İlacı"};
        for (String medication : commonMedications) {
            if (random.nextDouble() < 0.2) { // %20 olasılık
                medications.add(medication);
            }
        }

        // Geçmiş tıbbi kayıtlar
        String[] pastConditions = {"Grip", "Bronşit", "Migren", "Gastrit", "Hipertansiyon", "COVID-19", "Sinüzit"};
        for (int i = 0; i < random.nextInt(3) + 1; i++) {
            LocalDateTime pastDate = LocalDateTime.now().minusDays(random.nextInt(365) + 30);
            medicalHistory.add(new MedicalHistory(
                    pastConditions[random.nextInt(pastConditions.length)],
                    pastDate,
                    "Tedavi tamamlandı"
            ));
        }
    }

    public void addEmergencyCall(String condition, String hospital, LocalDateTime timestamp, Priority priority) {
        emergencyCalls.add(new EmergencyCall(condition, hospital, timestamp, priority));
    }

    public String getDetailedInfo() {
        StringBuilder info = new StringBuilder();
        info.append("👤 ").append(fullName).append(" (").append(age).append(" yaş)\n");
        info.append("🩸 Kan Grubu: ").append(bloodType).append("\n");
        info.append("⚧ Cinsiyet: ").append(gender).append("\n");
        info.append("📞 Telefon: ").append(phoneNumber).append("\n");
        info.append("🏠 Adres: ").append(address).append("\n\n");

        if (!allergies.isEmpty()) {
            info.append("⚠️ ALERJİLER:\n");
            allergies.forEach(allergy -> info.append("• ").append(allergy).append("\n"));
            info.append("\n");
        }

        if (!medications.isEmpty()) {
            info.append("💊 KULLANDIĞI İLAÇLAR:\n");
            medications.forEach(med -> info.append("• ").append(med).append("\n"));
            info.append("\n");
        }

        if (!emergencyCalls.isEmpty()) {
            info.append("🚨 ACIL ÇAĞRI GEÇMİŞİ:\n");
            emergencyCalls.stream()
                    .sorted((a, b) -> b.timestamp.compareTo(a.timestamp))
                    .limit(3)
                    .forEach(call -> info.append("• ").append(call.toString()).append("\n"));
        }

        return info.toString();
    }

    public Priority calculateCurrentPriority(String currentCondition) {
        // Hasta geçmişine göre öncelik hesapla
        if (allergies.contains("Penisilin") && currentCondition.contains("Enfeksiyon")) {
            return Priority.CRITICAL;
        }

        if (age > 70 || age < 5) {
            return Priority.HIGH;
        }

        if (medications.contains("Kalp İlacı") &&
                (currentCondition.contains("Kalp") || currentCondition.contains("Göğüs"))) {
            return Priority.CRITICAL;
        }

        return switch (currentCondition) {
            case "Kalp Krizi", "Beyin Kanaması", "Solunum Durması" -> Priority.CRITICAL;
            case "Travma", "Kemik Kırığı", "Yanık" -> Priority.HIGH;
            case "Bayılma", "Baş Ağrısı" -> Priority.MEDIUM;
            default -> Priority.LOW;
        };
    }

    // Getters
    public String getPatientId() { return patientId; }
    public String getFullName() { return fullName; }
    public int getAge() { return age; }
    public String getBloodType() { return bloodType; }
    public String getGender() { return gender; }
    public String getPhoneNumber() { return phoneNumber; }
    public String getAddress() { return address; }
    public List<MedicalHistory> getMedicalHistory() { return medicalHistory; }
    public List<EmergencyCall> getEmergencyCalls() { return emergencyCalls; }
    public Set<String> getAllergies() { return allergies; }
    public Set<String> getMedications() { return medications; }

    // Inner classes
    public static class MedicalHistory {
        private final String condition;
        private final LocalDateTime date;
        private final String treatment;

        public MedicalHistory(String condition, LocalDateTime date, String treatment) {
            this.condition = condition;
            this.date = date;
            this.treatment = treatment;
        }

        public String getCondition() { return condition; }
        public LocalDateTime getDate() { return date; }
        public String getTreatment() { return treatment; }

        @Override
        public String toString() {
            return String.format("%s - %s (%s)",
                    condition,
                    date.format(DateTimeFormatter.ofPattern("dd.MM.yyyy")),
                    treatment);
        }
    }

    public static class EmergencyCall {
        private final String condition;
        private final String hospital;
        private final LocalDateTime timestamp;
        private final Priority priority;

        public EmergencyCall(String condition, String hospital, LocalDateTime timestamp, Priority priority) {
            this.condition = condition;
            this.hospital = hospital;
            this.timestamp = timestamp;
            this.priority = priority;
        }

        public String getCondition() { return condition; }
        public String getHospital() { return hospital; }
        public LocalDateTime getTimestamp() { return timestamp; }
        public Priority getPriority() { return priority; }

        @Override
        public String toString() {
            return String.format("%s %s → %s (%s)",
                    priority.getDisplay(),
                    condition,
                    hospital,
                    timestamp.format(DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm")));
        }
    }
}