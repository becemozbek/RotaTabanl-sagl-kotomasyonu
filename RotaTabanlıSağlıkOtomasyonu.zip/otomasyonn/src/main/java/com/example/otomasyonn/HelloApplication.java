package com.example.otomasyonn;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Screen;
import javafx.stage.Stage;

public class HelloApplication extends Application {
    @Override
    public void start(Stage primaryStage) throws Exception {
        FXMLLoader loader = new FXMLLoader(
                getClass().getResource("hello-view.fxml")
        );

        // Ekran boyutunu tespit et
        Screen primaryScreen = Screen.getPrimary();
        double screenWidth = primaryScreen.getBounds().getWidth();
        double screenHeight = primaryScreen.getBounds().getHeight();

        // Başlangıç boyutları
        double initialWidth = 1400;
        double initialHeight = 900;

        // 1920x1080 veya daha büyükse büyük boyutta başlat
        if (screenWidth >= 1920 && screenHeight >= 1080) {
            initialWidth = 1600;
            initialHeight = 1000;
        }

        Scene scene = new Scene(loader.load(), initialWidth, initialHeight);

        primaryStage.setScene(scene);
        primaryStage.setTitle("🚑 112 Acil Çağrı Merkezi - Ambulans Takip Sistemi");

        // Minimum boyutlar
        primaryStage.setMinWidth(1200);
        primaryStage.setMinHeight(800);

        // Ekranın ortasında başlat
        primaryStage.setX((screenWidth - initialWidth) / 2);
        primaryStage.setY((screenHeight - initialHeight) / 2);

        // Uygulama ikonu
        try {
            primaryStage.getIcons().add(new Image(getClass().getResourceAsStream("/com/example/otomasyonn/ambulance.png")));
        } catch (Exception e) {
            System.out.println("Ikon yüklenemedi: " + e.getMessage());
        }

        // Tam ekran desteği
        primaryStage.setFullScreenExitHint("F11 ile tam ekran, ESC ile çıkış");

        primaryStage.show();

        System.out.println("🚀 112 Acil Otomasyon Sistemi başlatıldı");
        System.out.println("📐 Başlangıç boyutu: " + initialWidth + "x" + initialHeight);
    }

    public static void main(String[] args) {
        launch(args);
    }
}