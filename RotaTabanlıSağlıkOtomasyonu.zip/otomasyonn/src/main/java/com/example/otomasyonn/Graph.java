package com.example.otomasyonn;

import java.util.*;

/**
 * Özel graf implementasyonu - Dijkstra algoritması manuel olarak yazıldı
 * PriorityQueue yerine basit heap mantığı kullanıldı
 */
public class Graph {
    private final Map<Node, List<Edge>> adjacencyList = new HashMap<>();

    /** Yeni düğüm ekle */
    public void addNode(Node node) {
        adjacencyList.putIfAbsent(node, new ArrayList<>());
    }

    /** İki düğüm arası kenar ekle (çift yönlü) */
    public void addEdge(Node from, Node to, double distance, double congestion) {
        addDirectedEdge(from, to, distance, congestion, "street");
        addDirectedEdge(to, from, distance, congestion, "street");
    }

    /** Yönlü kenar ekle */
    public void addDirectedEdge(Node from, Node to, double distance, double congestion, String roadType) {
        adjacencyList.get(from).add(new Edge(from, to, distance, congestion, roadType));
    }

    /**
     * Manual Dijkstra implementasyonu - En kısa yol bulma
     * @param source Başlangıç düğümü
     * @param previous Yol reconstruct etmek için parent map
     * @return Her düğüme olan minimum mesafe
     */
    public Map<Node, Double> dijkstra(Node source, Map<Node, Node> previous) {
        Map<Node, Double> distances = new HashMap<>();
        Set<Node> visited = new HashSet<>();

        // Tüm düğümleri sonsuz mesafe ile başlat
        for (Node node : adjacencyList.keySet()) {
            distances.put(node, Double.POSITIVE_INFINITY);
        }
        distances.put(source, 0.0);

        // Manual priority queue benzeri işlem
        for (int i = 0; i < adjacencyList.size(); i++) {
            Node current = findMinDistanceNode(distances, visited);
            if (current == null) break;

            visited.add(current);

            // Komşuları güncelle
            for (Edge edge : adjacencyList.get(current)) {
                Node neighbor = edge.getTo();
                if (visited.contains(neighbor)) continue;

                double newDistance = distances.get(current) + edge.getWeight();
                if (newDistance < distances.get(neighbor)) {
                    distances.put(neighbor, newDistance);
                    previous.put(neighbor, current);
                }
            }
        }

        return distances;
    }

    /**
     * Ziyaret edilmemiş düğümler arasından en kısa mesafeli olanı bul
     */
    private Node findMinDistanceNode(Map<Node, Double> distances, Set<Node> visited) {
        Node minNode = null;
        double minDistance = Double.POSITIVE_INFINITY;

        for (Map.Entry<Node, Double> entry : distances.entrySet()) {
            Node node = entry.getKey();
            double distance = entry.getValue();

            if (!visited.contains(node) && distance < minDistance) {
                minDistance = distance;
                minNode = node;
            }
        }

        return minNode;
    }

    /** Yol reconstruction - başlangıçtan hedefe giden yolu döndür */
    public List<Node> reconstructPath(Node target, Map<Node, Node> previous) {
        List<Node> path = new ArrayList<>();
        Node current = target;

        while (current != null) {
            path.add(0, current); // Başa ekle
            current = previous.get(current);
        }

        return path;
    }

    public Map<Node, List<Edge>> getAdjacencyList() {
        return adjacencyList;
    }
}