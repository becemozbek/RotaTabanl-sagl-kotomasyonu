package com.example.otomasyonn;

import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Tıbbi personel takip ve yönetim sistemi
 * Doktor, hemşire ve paramedik müsaitlik durumu
 */
public class MedicalStaffSystem {

    private final List<MedicalStaff> allStaff;
    private final Map<String, List<MedicalStaff>> hospitalStaff;
    private final Map<String, ShiftSchedule> shiftSchedules;
    private final Random random;

    public enum StaffType {
        DOCTOR("👨‍⚕️ Doktor", 1),
        NURSE("👩‍⚕️ Hemşire", 2),
        PARAMEDIC("🚑 Paramedik", 3),
        SPECIALIST("🔬 Uzman Dr.", 1),
        SURGEON("🏥 Cerrah", 1);

        private final String display;
        private final int priority;

        StaffType(String display, int priority) {
            this.display = display;
            this.priority = priority;
        }

        public String getDisplay() { return display; }
        public int getPriority() { return priority; }
    }

    public enum StaffStatus {
        AVAILABLE("🟢 Müsait"),
        BUSY("🟡 Meşgul"),
        IN_SURGERY("🔴 Ameliyatta"),
        ON_CALL("🟠 Nöbette"),
        OFF_DUTY("⚫ Mesai Dışı"),
        EMERGENCY("🚨 Acil Görevde");

        private final String display;
        StaffStatus(String display) { this.display = display; }
        public String getDisplay() { return display; }
    }

    public enum Specialization {
        EMERGENCY("Acil Tıp"), CARDIOLOGY("Kardiyoloji"), NEUROLOGY("Nöroloji"),
        ORTHOPEDICS("Ortopedi"), PEDIATRICS("Çocuk Sağlığı"), SURGERY("Genel Cerrahi"),
        TRAUMA("Travma"), INTERNAL("İç Hastalıkları"), RADIOLOGY("Radyoloji"),
        ANESTHESIA("Anestezi"), ICU("Yoğun Bakım");

        private final String display;
        Specialization(String display) { this.display = display; }
        public String getDisplay() { return display; }
    }

    public MedicalStaffSystem() {
        this.allStaff = new ArrayList<>();
        this.hospitalStaff = new HashMap<>();
        this.shiftSchedules = new HashMap<>();
        this.random = new Random();

        generateMedicalStaff();
        generateShiftSchedules();
        updateStaffStatuses();
    }

    private void generateMedicalStaff() {
        String[] doctorNames = {
                "Dr. Ahmet Kaya", "Dr. Ayşe Demir", "Dr. Mehmet Özkan", "Dr. Fatma Yıldız",
                "Dr. Ali Şahin", "Dr. Zeynep Arslan", "Dr. Mustafa Çelik", "Dr. Elif Doğan"
        };

        String[] nurseNames = {
                "Hemşire Meryem Aydın", "Hemşire Hasan Polat", "Hemşire Sevim Erdoğan",
                "Hemşire İbrahim Koç", "Hemşire Emine Yılmaz", "Hemşire Osman Kara"
        };

        String[] paramedicNames = {
                "Paramedik Can Özdemir", "Paramedik Selin Aktaş", "Paramedik Burak Tekin",
                "Paramedik Deniz Yavuz", "Paramedik Cem Bulut", "Paramedik Pınar Çakır"
        };

        String[] hospitalNames = {
                "Ankara Şehir Hastanesi", "Hacettepe Üniversitesi", "Gülhane Askeri",
                "Başkent Üniversitesi", "Medicana Sağlık", "Acıbadem Hastanesi",
                "Memorial Sağlık", "Bayındır Acil Merkezi"
        };

        // Her hastane için personel oluştur
        for (String hospital : hospitalNames) {
            List<MedicalStaff> staffList = new ArrayList<>();

            // Doktorlar
            for (int i = 0; i < 3 + random.nextInt(3); i++) {
                String name = doctorNames[random.nextInt(doctorNames.length)];
                Specialization spec = Specialization.values()[random.nextInt(Specialization.values().length)];
                StaffType type = random.nextDouble() < 0.3 ? StaffType.SPECIALIST : StaffType.DOCTOR;

                MedicalStaff doctor = new MedicalStaff(
                        generateStaffId(), name, type, spec, hospital,
                        5 + random.nextInt(20), // 5-25 yıl deneyim
                        random.nextDouble() < 0.8 ? StaffStatus.AVAILABLE : StaffStatus.BUSY
                );

                staffList.add(doctor);
                allStaff.add(doctor);
            }

            // Hemşireler
            for (int i = 0; i < 4 + random.nextInt(4); i++) {
                String name = nurseNames[random.nextInt(nurseNames.length)];
                Specialization spec = Specialization.values()[random.nextInt(Specialization.values().length)];

                MedicalStaff nurse = new MedicalStaff(
                        generateStaffId(), name, StaffType.NURSE, spec, hospital,
                        2 + random.nextInt(15), // 2-17 yıl deneyim
                        random.nextDouble() < 0.7 ? StaffStatus.AVAILABLE : StaffStatus.BUSY
                );

                staffList.add(nurse);
                allStaff.add(nurse);
            }

            // Paramedikler
            for (int i = 0; i < 2 + random.nextInt(3); i++) {
                String name = paramedicNames[random.nextInt(paramedicNames.length)];

                MedicalStaff paramedic = new MedicalStaff(
                        generateStaffId(), name, StaffType.PARAMEDIC, Specialization.EMERGENCY, hospital,
                        1 + random.nextInt(12), // 1-13 yıl deneyim
                        random.nextDouble() < 0.9 ? StaffStatus.AVAILABLE : StaffStatus.ON_CALL
                );

                staffList.add(paramedic);
                allStaff.add(paramedic);
            }

            hospitalStaff.put(hospital, staffList);
        }
    }

    private String generateStaffId() {
        return "ST" + String.format("%04d", 1000 + random.nextInt(9000));
    }

    private void generateShiftSchedules() {
        // Her hastane için vardiya çizelgesi oluştur
        for (String hospital : hospitalStaff.keySet()) {
            shiftSchedules.put(hospital, new ShiftSchedule(hospital));
        }
    }

    private void updateStaffStatuses() {
        LocalTime now = LocalTime.now();
        int hour = now.getHour();

        for (MedicalStaff staff : allStaff) {
            // Gece vardiyası kontrolü
            if (hour >= 22 || hour <= 6) {
                if (random.nextDouble() < 0.3) {
                    staff.setStatus(StaffStatus.ON_CALL);
                } else if (random.nextDouble() < 0.5) {
                    staff.setStatus(StaffStatus.OFF_DUTY);
                }
            }
            // Yoğun saatler
            else if (hour >= 8 && hour <= 18) {
                if (staff.getType() == StaffType.SURGEON && random.nextDouble() < 0.2) {
                    staff.setStatus(StaffStatus.IN_SURGERY);
                } else if (random.nextDouble() < 0.3) {
                    staff.setStatus(StaffStatus.BUSY);
                }
            }
        }
    }

    /**
     * Belirli hastanede belirli uzmanlık için müsait personeli bul
     */
    public List<MedicalStaff> findAvailableStaff(String hospital, Specialization specialization) {
        return hospitalStaff.getOrDefault(hospital, new ArrayList<>())
                .stream()
                .filter(staff -> staff.getSpecialization() == specialization)
                .filter(staff -> staff.getStatus() == StaffStatus.AVAILABLE ||
                        staff.getStatus() == StaffStatus.ON_CALL)
                .sorted((a, b) -> Integer.compare(a.getType().getPriority(), b.getType().getPriority()))
                .collect(Collectors.toList());
    }

    /**
     * Acil durum için en uygun personeli ata
     */
    public MedicalStaff assignEmergencyStaff(String hospital, String emergencyType) {
        Specialization requiredSpec = determineRequiredSpecialization(emergencyType);
        List<MedicalStaff> availableStaff = findAvailableStaff(hospital, requiredSpec);

        if (availableStaff.isEmpty()) {
            // Genel acil personeli ara
            availableStaff = findAvailableStaff(hospital, Specialization.EMERGENCY);
        }

        if (!availableStaff.isEmpty()) {
            MedicalStaff assigned = availableStaff.get(0);
            assigned.setStatus(StaffStatus.EMERGENCY);
            assigned.setCurrentTask("Acil Görev: " + emergencyType);
            return assigned;
        }

        return null; // Kimse müsait değil
    }

    private Specialization determineRequiredSpecialization(String emergencyType) {
        return switch (emergencyType.toLowerCase()) {
            case "kalp krizi", "kalp" -> Specialization.CARDIOLOGY;
            case "beyin kanaması", "felç" -> Specialization.NEUROLOGY;
            case "kemik kırığı", "travma" -> Specialization.ORTHOPEDICS;
            case "çocuk acil", "çocuk" -> Specialization.PEDIATRICS;
            case "ameliyat", "cerrahi" -> Specialization.SURGERY;
            default -> Specialization.EMERGENCY;
        };
    }

    /**
     * Personelin görevini tamamla ve müsait yap
     */
    public void completeStaffTask(String staffId) {
        allStaff.stream()
                .filter(staff -> staff.getStaffId().equals(staffId))
                .findFirst()
                .ifPresent(staff -> {
                    staff.setStatus(StaffStatus.AVAILABLE);
                    staff.setCurrentTask(null);
                });
    }

    /**
     * Hastane personel durumu raporu
     */
    public String getHospitalStaffReport(String hospital) {
        List<MedicalStaff> staff = hospitalStaff.get(hospital);
        if (staff == null || staff.isEmpty()) {
            return "Bu hastanede kayıtlı personel bulunamadı.";
        }

        StringBuilder report = new StringBuilder();
        report.append("👥 ").append(hospital).append(" PERSONEL DURUMU\n\n");

        // Duruma göre grupla
        Map<StaffStatus, List<MedicalStaff>> statusGroups = staff.stream()
                .collect(Collectors.groupingBy(MedicalStaff::getStatus));

        for (StaffStatus status : StaffStatus.values()) {
            if (statusGroups.containsKey(status)) {
                report.append(status.getDisplay()).append(" (").append(statusGroups.get(status).size()).append("):\n");
                statusGroups.get(status).forEach(s ->
                        report.append("• ").append(s.getName()).append(" - ").append(s.getSpecialization().getDisplay()).append("\n"));
                report.append("\n");
            }
        }

        return report.toString();
    }

    /**
     * Genel sistem durumu
     */
    public String getSystemStatus() {
        StringBuilder status = new StringBuilder();
        status.append("👨‍⚕️ TIBBİ PERSONEL SİSTEM DURUMU\n\n");

        // Toplam sayılar
        Map<StaffType, Long> typeCounts = allStaff.stream()
                .collect(Collectors.groupingBy(MedicalStaff::getType, Collectors.counting()));

        status.append("📊 PERSONEL SAYILARI:\n");
        typeCounts.forEach((type, count) ->
                status.append("• ").append(type.getDisplay()).append(": ").append(count).append("\n"));

        status.append("\n📈 MÜSAİTLİK DURUMU:\n");
        Map<StaffStatus, Long> statusCounts = allStaff.stream()
                .collect(Collectors.groupingBy(MedicalStaff::getStatus, Collectors.counting()));

        statusCounts.forEach((stat, count) ->
                status.append("• ").append(stat.getDisplay()).append(": ").append(count).append("\n"));

        return status.toString();
    }

    // Getter methods
    public List<MedicalStaff> getAllStaff() { return new ArrayList<>(allStaff); }
    public Map<String, List<MedicalStaff>> getHospitalStaff() { return new HashMap<>(hospitalStaff); }

    /**
     * Tıbbi personel sınıfı
     */
    public static class MedicalStaff {
        private final String staffId;
        private final String name;
        private final StaffType type;
        private final Specialization specialization;
        private final String hospital;
        private final int experienceYears;
        private StaffStatus status;
        private String currentTask;
        private LocalDateTime lastStatusUpdate;

        public MedicalStaff(String staffId, String name, StaffType type, Specialization specialization,
                            String hospital, int experienceYears, StaffStatus status) {
            this.staffId = staffId;
            this.name = name;
            this.type = type;
            this.specialization = specialization;
            this.hospital = hospital;
            this.experienceYears = experienceYears;
            this.status = status;
            this.lastStatusUpdate = LocalDateTime.now();
        }

        // Getters and Setters
        public String getStaffId() { return staffId; }
        public String getName() { return name; }
        public StaffType getType() { return type; }
        public Specialization getSpecialization() { return specialization; }
        public String getHospital() { return hospital; }
        public int getExperienceYears() { return experienceYears; }
        public StaffStatus getStatus() { return status; }
        public String getCurrentTask() { return currentTask; }
        public LocalDateTime getLastStatusUpdate() { return lastStatusUpdate; }

        public void setStatus(StaffStatus status) {
            this.status = status;
            this.lastStatusUpdate = LocalDateTime.now();
        }

        public void setCurrentTask(String currentTask) {
            this.currentTask = currentTask;
        }

        public String getDisplayInfo() {
            StringBuilder info = new StringBuilder();
            info.append(type.getDisplay()).append(" ").append(name).append("\n");
            info.append("🏥 ").append(hospital).append("\n");
            info.append("⚕️ ").append(specialization.getDisplay()).append("\n");
            info.append("📅 ").append(experienceYears).append(" yıl deneyim\n");
            info.append("📊 ").append(status.getDisplay()).append("\n");
            if (currentTask != null) {
                info.append("📋 ").append(currentTask).append("\n");
            }
            return info.toString();
        }

        @Override
        public String toString() {
            return String.format("%s - %s (%s)", name, specialization.getDisplay(), status.getDisplay());
        }
    }

    /**
     * Vardiya çizelgesi sınıfı
     */
    public static class ShiftSchedule {
        private final String hospital;
        private final Map<String, String> dailyShifts;

        public ShiftSchedule(String hospital) {
            this.hospital = hospital;
            this.dailyShifts = new HashMap<>();
            generateWeeklySchedule();
        }

        private void generateWeeklySchedule() {
            String[] days = {"Pazartesi", "Salı", "Çarşamba", "Perşembe", "Cuma", "Cumartesi", "Pazar"};
            String[] shifts = {"08:00-16:00", "16:00-00:00", "00:00-08:00"};

            Random random = new Random();
            for (String day : days) {
                dailyShifts.put(day, shifts[random.nextInt(shifts.length)]);
            }
        }

        public String getHospital() { return hospital; }
        public Map<String, String> getDailyShifts() { return dailyShifts; }
    }
}