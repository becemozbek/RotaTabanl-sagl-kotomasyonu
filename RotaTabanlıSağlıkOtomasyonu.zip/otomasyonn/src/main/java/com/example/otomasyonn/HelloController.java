package com.example.otomasyonn;

import javafx.animation.*;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.geometry.Point2D;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.LineTo;
import javafx.scene.shape.MoveTo;
import javafx.scene.shape.Path;
import javafx.util.Duration;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import java.net.URL;
import java.time.LocalDateTime;
import java.util.*;

public class HelloController {

    @FXML private Pane mapPane;
    @FXML private ImageView mapImage;
    @FXML private Canvas canvas;
    @FXML private ImageView ambulanceIv;
    @FXML private ComboBox<String> condCb;
    @FXML private ComboBox<String> specFilterCb;
    @FXML private Slider congestionSlider;
    @FXML private Label congestionValue;
    @FXML private Label selectedHomeLabel;
    @FXML private Button callAmbulanceBtn;
    @FXML private CheckBox sirenCb;
    @FXML private Slider speedSlider;
    @FXML private ListView<Hospital> hospitalList;
    @FXML private ListView<String> ambulanceList;
    @FXML private ListView<String> completedList;
    @FXML private TextArea detailArea;
    @FXML private Label statusLabel;
    @FXML private StackPane toastPane;
    @FXML private Label coordLabel;
    @FXML private ProgressBar emergencyBar;
    @FXML private Label emergencyCountLabel;

    private Graph graph;
    private Map<Node, Point2D> nodeCoordinates;
    private List<Node> homeNodes;
    private List<Hospital> hospitals;
    private Set<String> allSpecialties;
    private Node selectedHome;
    private Clip sirenClip;

    private final ObservableList<String> activeAmbulances = FXCollections.observableArrayList();
    private final ObservableList<String> completedMissions = FXCollections.observableArrayList();
    private final Map<String, Double> ambulanceTimers = new HashMap<>();
    private final Map<String, List<Point2D>> ambulanceRoutes = new HashMap<>();

    private WeatherTrafficSystem weatherTrafficSystem;
    private MedicalStaffSystem medicalStaffSystem;
    private final Map<Node, PatientRecord> patientRecords = new HashMap<>();

    // Görsel kaynaklar
    private Image homeIcon;
    private Image hospitalIcon;
    private Image ambulanceIcon;

    // Harita boyutları ve ikon ayarları
    private double actualMapWidth = 900;
    private double actualMapHeight = 600;
    private final double ICON_SIZE = 30;
    private final double MIN_DISTANCE_BETWEEN_ICONS = 60;

    private int totalEmergencies = 0;
    private int completedEmergencies = 0;

    // İkon çoğalmasını önlemek için
    private boolean iconsPlaced = false;
    private final List<Button> homeButtons = new ArrayList<>();
    private final List<Button> hospitalButtons = new ArrayList<>();

    @FXML
    public void initialize() {
        System.out.println("🚀 112 Acil Sistem Initialize başladı!");

        loadIcons();
        setupMapView();
        setupAmbulanceIcon();
        setupListViews();
        initializeDataModel();
        initializeAdvancedSystems();
        initializeControls();

        Platform.runLater(() -> {
            calculateActualMapDimensions();
            if (!iconsPlaced) {
                placeCityMarkers();
                iconsPlaced = true;
            }
            updateHospitalListView();
        });

        setupMapInteractions();
        setupSoundSystem();

        System.out.println("✅ Initialize tamamlandı!");
    }

    private void loadIcons() {
        try {
            homeIcon = new Image(getClass().getResourceAsStream("/com/example/otomasyonn/home.png"));
            System.out.println("✅ home.png yüklendi");
        } catch (Exception e) {
            System.err.println("❌ home.png yüklenemedi: " + e.getMessage());
            homeIcon = null;
        }

        try {
            hospitalIcon = new Image(getClass().getResourceAsStream("/com/example/otomasyonn/hospital.png"));
            System.out.println("✅ hospital.png yüklendi");
        } catch (Exception e) {
            System.err.println("❌ hospital.png yüklenemedi: " + e.getMessage());
            hospitalIcon = null;
        }

        try {
            ambulanceIcon = new Image(getClass().getResourceAsStream("/com/example/otomasyonn/ambulance.png"));
            System.out.println("✅ ambulance.png yüklendi");
        } catch (Exception e) {
            System.err.println("❌ ambulance.png yüklenemedi: " + e.getMessage());
            ambulanceIcon = null;
        }
    }

    private void calculateActualMapDimensions() {
        double paneWidth = mapPane.getWidth();
        double paneHeight = mapPane.getHeight();

        if (paneWidth > 0 && paneHeight > 0) {
            // Harita TAM pane boyutunu kullansın - boş alan kalmasın
            actualMapWidth = paneWidth;
            actualMapHeight = paneHeight;

            // Harita tam pane'i kaplasın
            mapImage.setLayoutX(0);
            mapImage.setLayoutY(0);
            mapImage.setFitWidth(actualMapWidth);
            mapImage.setFitHeight(actualMapHeight);
            mapImage.setPreserveRatio(false); // Oranı bozulsun ama tam kaplasın

            canvas.setLayoutX(0);
            canvas.setLayoutY(0);
            canvas.setWidth(actualMapWidth);
            canvas.setHeight(actualMapHeight);
        }

        System.out.println("📐 Harita TAM BOYUT: " + actualMapWidth + "x" + actualMapHeight);
    }

    private void setupMapView() {
        Image mapImg = new Image(getClass().getResourceAsStream("/com/example/otomasyonn/map.png"));
        mapImage.setImage(mapImg);
        mapImage.setPreserveRatio(true);

        System.out.println("🗺️ Harita kurulumu tamamlandı");
    }

    private void setupAmbulanceIcon() {
        ambulanceIv.setImage(ambulanceIcon);
        ambulanceIv.setVisible(false);
        ambulanceIv.setFitWidth(40);
        ambulanceIv.setFitHeight(40);
    }

    private void setupListViews() {
        ambulanceList.setItems(activeAmbulances);
        completedList.setItems(completedMissions);
    }

    private void initializeDataModel() {
        graph = new Graph();
        nodeCoordinates = new HashMap<>();
        homeNodes = new ArrayList<>();
        hospitals = new ArrayList<>();
        allSpecialties = new TreeSet<>();

        createCityLayout();
        createHospitalNetwork();
        buildRoadNetwork();
    }

    private void initializeAdvancedSystems() {
        weatherTrafficSystem = new WeatherTrafficSystem();
        medicalStaffSystem = new MedicalStaffSystem();
        setupResponsiveDesign();

        Timeline systemUpdateTimer = new Timeline(new KeyFrame(Duration.seconds(30), e -> {
            weatherTrafficSystem.updateSystem();
            updateSystemStatus();
        }));
        systemUpdateTimer.setCycleCount(Timeline.INDEFINITE);
        systemUpdateTimer.play();
    }

    private void setupResponsiveDesign() {
        Platform.runLater(() -> {
            javafx.stage.Stage stage = (javafx.stage.Stage) mapPane.getScene().getWindow();

            if (stage == null) return;

            javafx.stage.Screen screen = javafx.stage.Screen.getPrimary();
            double screenWidth = screen.getBounds().getWidth();
            double screenHeight = screen.getBounds().getHeight();

            if (screenWidth >= 1920 && screenHeight >= 1080) {
                stage.setWidth(1600);
                stage.setHeight(1000);
                callAmbulanceBtn.setPrefHeight(55);
                callAmbulanceBtn.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");
                System.out.println("✅ Büyük ekran için optimize edildi");
            } else {
                stage.setWidth(1400);
                stage.setHeight(900);
                System.out.println("📱 Standart ekran boyutu ayarlandı");
            }

            stage.centerOnScreen();

            // F11 tam ekran kontrolü
            stage.fullScreenProperty().addListener((obs, oldVal, newVal) -> {
                Platform.runLater(() -> {
                    calculateActualMapDimensions();
                    repositionIcons();
                });
            });

            // Pencere boyut değişikliklerini dinle
            stage.widthProperty().addListener((obs, oldVal, newVal) -> {
                Platform.runLater(() -> {
                    calculateActualMapDimensions();
                    repositionIcons();
                });
            });

            stage.heightProperty().addListener((obs, oldVal, newVal) -> {
                Platform.runLater(() -> {
                    calculateActualMapDimensions();
                    repositionIcons();
                });
            });

            // F11 tuş kontrolü
            mapPane.getScene().setOnKeyPressed(event -> {
                if (event.getCode() == javafx.scene.input.KeyCode.F11) {
                    stage.setFullScreen(!stage.isFullScreen());
                }
            });
        });
    }

    private void repositionIcons() {
        if (!iconsPlaced) return;

        // Basit scale hesaplama - tam pane boyutuna göre
        double scaleX = actualMapWidth / 900.0;
        double scaleY = actualMapHeight / 600.0;

        // Offset yok - harita tam 0,0'dan başlıyor
        double offsetX = 0;
        double offsetY = 0;

        // Ev ikonlarını yeniden konumlandır
        for (int i = 0; i < homeButtons.size() && i < homeNodes.size(); i++) {
            Button homeButton = homeButtons.get(i);
            Node home = homeNodes.get(i);
            Point2D originalPosition = nodeCoordinates.get(home);

            if (originalPosition != null) {
                double scaledX = originalPosition.getX() * scaleX;
                double scaledY = originalPosition.getY() * scaleY;

                homeButton.setLayoutX(scaledX - ICON_SIZE / 2);
                homeButton.setLayoutY(scaledY - ICON_SIZE / 2);
            }
        }

        // Hastane ikonlarını yeniden konumlandır
        for (int i = 0; i < hospitalButtons.size() && i < hospitals.size(); i++) {
            Button hospitalButton = hospitalButtons.get(i);
            Hospital hospital = hospitals.get(i);
            Point2D originalPosition = nodeCoordinates.get(hospital.getLocation());

            if (originalPosition != null) {
                double scaledX = originalPosition.getX() * scaleX;
                double scaledY = originalPosition.getY() * scaleY;

                hospitalButton.setLayoutX(scaledX - (ICON_SIZE + 5) / 2);
                hospitalButton.setLayoutY(scaledY - (ICON_SIZE + 5) / 2);
            }
        }

        System.out.println("🔄 İkonlar TAM BOYUT için yeniden konumlandırıldı");
    }

    private void createCityLayout() {
        System.out.println("🏠 Evler rastgele yerleştiriliyor...");

        double safeMarginX = 80;
        double safeMarginY = 80;
        double safeWidth = 900 - (2 * safeMarginX);  // Orijinal boyutlarda hesapla
        double safeHeight = 600 - (2 * safeMarginY);

        List<Point2D> usedPositions = new ArrayList<>();
        Random random = new Random(System.currentTimeMillis());

        for (int i = 1; i <= 12; i++) {
            Node homeNode = new Node("E" + i);
            homeNode.setDisplayName("Ev " + i);
            graph.addNode(homeNode);

            Point2D position = findSafeRandomPosition(usedPositions, safeMarginX, safeMarginY,
                    safeWidth, safeHeight, random, 50);

            nodeCoordinates.put(homeNode, position);
            homeNodes.add(homeNode);
            usedPositions.add(position);

            System.out.println("🏠 Ev " + i + " pozisyon: (" + (int) position.getX() + ", " + (int) position.getY() + ")");
        }

        generatePatientRecords();
    }

    private Point2D findSafeRandomPosition(List<Point2D> usedPositions, double marginX, double marginY,
                                           double safeWidth, double safeHeight, Random random, int maxAttempts) {
        for (int attempt = 0; attempt < maxAttempts; attempt++) {
            double x = marginX + random.nextDouble() * safeWidth;
            double y = marginY + random.nextDouble() * safeHeight;
            Point2D candidate = new Point2D(x, y);

            boolean isSafe = true;
            for (Point2D used : usedPositions) {
                if (candidate.distance(used) < MIN_DISTANCE_BETWEEN_ICONS) {
                    isSafe = false;
                    break;
                }
            }

            if (isSafe) {
                return candidate;
            }
        }

        // Grid sistemi fallback
        int gridSize = (int) Math.ceil(Math.sqrt(usedPositions.size() + 1));
        double gridSpacingX = safeWidth / (gridSize + 1);
        double gridSpacingY = safeHeight / (gridSize + 1);

        int index = usedPositions.size();
        int row = index / gridSize;
        int col = index % gridSize;

        double x = marginX + (col + 1) * gridSpacingX;
        double y = marginY + (row + 1) * gridSpacingY;

        System.out.println("⚠️ Grid pozisyonu kullanıldı: (" + (int) x + ", " + (int) y + ")");
        return new Point2D(x, y);
    }

    private void generatePatientRecords() {
        String[] firstNames = {"Mehmet", "Ayşe", "Mustafa", "Hatice", "Ahmet", "Zeynep", "Murat", "Elif", "Emre", "Seda", "Burak", "Gülşen"};
        String[] lastNames = {"Yılmaz", "Kaya", "Demir", "Çelik", "Şahin", "Özkan", "Aydın", "Özdemir", "Arslan", "Doğan", "Kılıç", "Aslan"};
        String[] bloodTypes = {"A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"};
        String[] genders = {"Erkek", "Kadın"};

        Random random = new Random();

        for (Node home : homeNodes) {
            String firstName = firstNames[random.nextInt(firstNames.length)];
            String lastName = lastNames[random.nextInt(lastNames.length)];
            String fullName = firstName + " " + lastName;
            int age = 1 + random.nextInt(85);
            String bloodType = bloodTypes[random.nextInt(bloodTypes.length)];
            String gender = genders[random.nextInt(genders.length)];

            PatientRecord record = new PatientRecord("P" + home.getId().substring(1), fullName, age, bloodType, gender);
            patientRecords.put(home, record);
        }
    }

    private void updateSystemStatus() {
        Platform.runLater(() -> {
            String weatherInfo = weatherTrafficSystem.getWeatherReport();
        });
    }

    private void createHospitalNetwork() {
        System.out.println("🏥 İstanbul hastaneleri yerleştiriliyor...");

        double safeMarginX = 100;
        double safeMarginY = 100;
        double safeWidth = 900 - (2 * safeMarginX);  // Orijinal boyutlarda hesapla
        double safeHeight = 600 - (2 * safeMarginY);

        String[] hospitalNames = {
                "İstanbul Üniversitesi Cerrahpaşa", "Şişli Etfal Hastanesi", "Haydarpaşa Numune",
                "Acıbadem Maslak", "Memorial Şişli", "Koç Üniversitesi Hastanesi",
                "Medipol Mega Üniversite", "Bahçelievler Devlet Hastanesi"
        };

        Hospital.HospitalType[] hospitalTypes = {
                Hospital.HospitalType.UNIVERSITY, Hospital.HospitalType.STATE, Hospital.HospitalType.STATE,
                Hospital.HospitalType.PRIVATE, Hospital.HospitalType.PRIVATE, Hospital.HospitalType.UNIVERSITY,
                Hospital.HospitalType.PRIVATE, Hospital.HospitalType.STATE
        };

        String[][] hospitalSpecialties = {
                {"Acil Tıp", "Kalp Cerrahi", "Beyin Cerrahi", "Travma"},
                {"Çocuk Sağlığı", "Acil Tıp", "Nöroloji", "Ortopedi"},
                {"Travma", "Ortopedi", "Acil Tıp", "Göğüs Cerrahi"},
                {"Beyin Cerrahi", "Kalp Cerrahi", "Ortopedi", "Acil Tıp"},
                {"Nöroloji", "Kalp Cerrahi", "Acil Tıp", "Travma"},
                {"Kalp Cerrahi", "Beyin Cerrahi", "Çocuk Sağlığı", "Acil Tıp"},
                {"Çocuk Sağlığı", "Acil Tıp", "Nöroloji", "Travma"},
                {"Acil Tıp", "Travma", "Ortopedi", "Göğüs Cerrahi"}
        };

        List<Point2D> allUsedPositions = new ArrayList<>(nodeCoordinates.values());
        Random random = new Random(System.currentTimeMillis() + 1000);

        for (int i = 1; i <= 8; i++) {
            Node hospitalNode = new Node("H" + i);
            hospitalNode.setDisplayName(hospitalNames[i - 1]);
            graph.addNode(hospitalNode);

            Point2D position = findSafeRandomPosition(allUsedPositions, safeMarginX, safeMarginY,
                    safeWidth, safeHeight, random, 50);

            nodeCoordinates.put(hospitalNode, position);
            allUsedPositions.add(position);

            List<String> specialties = Arrays.asList(hospitalSpecialties[i - 1]);
            Hospital hospital = new Hospital(hospitalNames[i - 1], hospitalNode, specialties, hospitalTypes[i - 1], 50 + random.nextInt(200));
            hospital.setAmbulanceCount(2 + random.nextInt(3));
            hospitals.add(hospital);
            allSpecialties.addAll(specialties);

            System.out.println("🏥 " + hospitalNames[i - 1] + " pozisyon: (" + (int) position.getX() + ", " + (int) position.getY() + ")");
        }

        System.out.println("✅ " + homeNodes.size() + " ev ve " + hospitals.size() + " İstanbul hastanesi yerleştirildi");
    }

    private void buildRoadNetwork() {
        List<Node> allNodes = new ArrayList<>(homeNodes);
        hospitals.forEach(h -> allNodes.add(h.getLocation()));
        Random random = new Random(456);

        // Hastane-hastane bağlantıları
        for (int i = 0; i < hospitals.size(); i++) {
            for (int j = i + 1; j < hospitals.size(); j++) {
                Hospital h1 = hospitals.get(i);
                Hospital h2 = hospitals.get(j);
                double distance = nodeCoordinates.get(h1.getLocation()).distance(nodeCoordinates.get(h2.getLocation()));

                if (distance < 350) {
                    addNavigationalEdge(h1.getLocation(), h2.getLocation(), "highway");
                }
            }
        }

        // Ev-ev bağlantıları
        for (int i = 0; i < homeNodes.size(); i++) {
            for (int j = i + 1; j < homeNodes.size(); j++) {
                Node home1 = homeNodes.get(i);
                Node home2 = homeNodes.get(j);
                double distance = nodeCoordinates.get(home1).distance(nodeCoordinates.get(home2));

                if (distance < 200) {
                    addNavigationalEdge(home1, home2, "street");
                }
            }
        }

        // Ev-hastane bağlantıları
        for (Node home : homeNodes) {
            List<Hospital> nearbyHospitals = hospitals.stream()
                    .sorted((h1, h2) -> {
                        double d1 = nodeCoordinates.get(home).distance(nodeCoordinates.get(h1.getLocation()));
                        double d2 = nodeCoordinates.get(home).distance(nodeCoordinates.get(h2.getLocation()));
                        return Double.compare(d1, d2);
                    })
                    .limit(4)
                    .toList();

            for (Hospital hospital : nearbyHospitals) {
                addNavigationalEdge(home, hospital.getLocation(), "path");
            }
        }
    }

    private void addNavigationalEdge(Node from, Node to, String roadType) {
        Point2D p1 = nodeCoordinates.get(from);
        Point2D p2 = nodeCoordinates.get(to);
        double distance = p1.distance(p2) / 25.0;
        double congestion = 1.0 + new Random().nextDouble() * 0.5;

        graph.addDirectedEdge(from, to, distance, congestion, roadType);
        graph.addDirectedEdge(to, from, distance, congestion, roadType);
    }

    private void initializeControls() {
        condCb.getItems().setAll(
                "Kalp Krizi", "Beyin Kanaması", "Solunum Durması", "Şiddetli Kaza Travması", "Anafılaktik Şok",
                "Akut Apandisit", "Kemik Kırığı", "Doğum Komplikasyonu", "Yanık (2-3. Derece)", "Akut Astım Krizi",
                "Epilepsi Nöbeti", "Şeker Koması", "Akut Gastrit", "Hipertansif Kriz", "Böbrek Taşı Koliği",
                "Migren Atağı", "Gıda Zehirlenmesi", "Alerjik Reaksiyon", "Boyun Fıtığı", "Vertigo",
                "COVID-19 Ağır Seyir", "Panik Atak", "Akut Böbrek Yetmezliği", "Göz Travması"
        );
        condCb.getSelectionModel().selectFirst();
        condCb.setOnAction(e -> resetHomeSelection());

        specFilterCb.getItems().add("Tüm Hastaneler");
        specFilterCb.getItems().addAll(allSpecialties);
        specFilterCb.getSelectionModel().selectFirst();
        specFilterCb.setOnAction(e -> updateHospitalListView());

        congestionSlider.setMin(1.0);
        congestionSlider.setMax(3.0);
        congestionSlider.setValue(1.0);
        congestionValue.setText("Normal");
        congestionSlider.valueProperty().addListener((obs, oldVal, newVal) -> {
            String trafficLevel = newVal.doubleValue() < 1.5 ? "Düşük" : newVal.doubleValue() < 2.5 ? "Orta" : "Yoğun";
            congestionValue.setText(trafficLevel);
            resetHomeSelection();
        });

        sirenCb.setSelected(true);
        speedSlider.setMin(0.3);
        speedSlider.setMax(2.5);
        speedSlider.setValue(1.0);

        callAmbulanceBtn.setDisable(true);
        callAmbulanceBtn.setStyle("-fx-background-color: #FF4444; -fx-text-fill: white; -fx-font-weight: bold;");
        callAmbulanceBtn.setOnAction(e -> dispatchEmergencyAmbulance());

        hospitalList.setCellFactory(lv -> new ListCell<Hospital>() {
            @Override
            protected void updateItem(Hospital hospital, boolean empty) {
                super.updateItem(hospital, empty);
                if (empty || hospital == null) {
                    setText(null);
                    setGraphic(null);
                } else {
                    setText(hospital.getFullDisplayName());
                    setStyle("-fx-padding: 8px;");
                }
            }
        });

        if (emergencyBar != null) emergencyBar.setProgress(0.0);
        if (emergencyCountLabel != null) emergencyCountLabel.setText("0/0 Acil Durum");
    }

    private void placeCityMarkers() {
        System.out.println("🚀 Markerlar yerleştiriliyor...");

        // Önce mevcut button listelerini temizle
        homeButtons.clear();
        hospitalButtons.clear();

        // Basit scale - tam pane boyutuna göre
        double scaleX = actualMapWidth / 900.0;
        double scaleY = actualMapHeight / 600.0;

        // Offset yok - harita 0,0'dan başlıyor
        double offsetX = 0;
        double offsetY = 0;

        System.out.println("📏 TAM BOYUT Scale: X=" + String.format("%.3f", scaleX) + ", Y=" + String.format("%.3f", scaleY));

        // Ev ikonları
        for (int i = 0; i < homeNodes.size(); i++) {
            Node home = homeNodes.get(i);
            Point2D originalPosition = nodeCoordinates.get(home);
            final int homeIndex = i;

            Button homeButton = createLocationButton(home.getDisplayName(), homeIcon, "🏠", ICON_SIZE);

            if (originalPosition != null) {
                double scaledX = originalPosition.getX() * scaleX;
                double scaledY = originalPosition.getY() * scaleY;

                homeButton.setLayoutX(scaledX - ICON_SIZE / 2);
                homeButton.setLayoutY(scaledY - ICON_SIZE / 2);
            }

            homeButton.setOnAction(e -> {
                selectHomeForEmergency(home);
                PatientRecord patient = patientRecords.get(home);
                detailArea.setText(patient.getDetailedInfo());
                System.out.println("Ev " + (homeIndex + 1) + " seçildi!");
            });

            mapPane.getChildren().add(homeButton);
            homeButtons.add(homeButton);
            homeButton.toFront();
        }

        // Hastane ikonları
        for (int i = 0; i < hospitals.size(); i++) {
            Hospital hospital = hospitals.get(i);
            Point2D originalPosition = nodeCoordinates.get(hospital.getLocation());

            Button hospitalButton = createLocationButton(hospital.getName(), hospitalIcon, "🏥", ICON_SIZE + 5);

            if (originalPosition != null) {
                double scaledX = originalPosition.getX() * scaleX;
                double scaledY = originalPosition.getY() * scaleY;

                hospitalButton.setLayoutX(scaledX - (ICON_SIZE + 5) / 2);
                hospitalButton.setLayoutY(scaledY - (ICON_SIZE + 5) / 2);
            }

            hospitalButton.setOnAction(e -> {
                detailArea.setText(String.format("🏥 %s\n🚑 Ambulans: %d adet\n🏥 Tip: %s\n⚕️ Bölümler: %s",
                        hospital.getName(), hospital.getAmbulanceCount(),
                        hospital.getType().getDisplayName(), String.join(", ", hospital.getSpecialties())));
                System.out.println("Hastane " + hospital.getName() + " seçildi!");
            });

            mapPane.getChildren().add(hospitalButton);
            hospitalButtons.add(hospitalButton);
            hospitalButton.toFront();
        }

        System.out.println("✅ " + (homeButtons.size() + hospitalButtons.size()) + " marker TAM BOYUT için yerleştirildi!");
    }

    private Button createLocationButton(String name, Image icon, String fallbackEmoji, double size) {
        Button button = new Button();

        if (icon != null) {
            ImageView imageView = new ImageView(icon);
            imageView.setFitWidth(size);
            imageView.setFitHeight(size);
            imageView.setPreserveRatio(true);
            button.setGraphic(imageView);
        } else {
            button.setText(fallbackEmoji);
        }

        button.setStyle(
                "-fx-background-color: transparent; " +
                        "-fx-border-color: transparent; " +
                        "-fx-border-width: 0px; " +
                        "-fx-padding: 0px; " +
                        "-fx-background-radius: 0px; " +
                        "-fx-border-radius: 0px; " +
                        "-fx-cursor: hand; " +
                        "-fx-focus-color: transparent; " +
                        "-fx-faint-focus-color: transparent;"
        );

        button.setPrefWidth(size);
        button.setPrefHeight(size);
        button.setMinWidth(size);
        button.setMinHeight(size);
        button.setMaxWidth(size);
        button.setMaxHeight(size);

        button.setOnMouseEntered(e -> {
            button.setScaleX(1.1);
            button.setScaleY(1.1);
        });

        button.setOnMouseExited(e -> {
            button.setScaleX(1.0);
            button.setScaleY(1.0);
        });

        return button;
    }

    private void setupMapInteractions() {
        mapPane.setOnMouseMoved(event -> {
            coordLabel.setText(String.format("📍 Mouse: (%.0f, %.0f)", event.getX(), event.getY()));
        });
    }

    private void setupSoundSystem() {
        try {
            URL sirenUrl = getClass().getResource("/com/example/otomasyonn/siren.wav");
            if (sirenUrl != null) {
                AudioInputStream audioStream = AudioSystem.getAudioInputStream(sirenUrl);
                sirenClip = AudioSystem.getClip();
                sirenClip.open(audioStream);
            }
        } catch (Exception ex) {
            System.err.println("Siren sesi yüklenemedi: " + ex.getMessage());
        }
    }

    private void updateHospitalListView() {
        String selectedFilter = specFilterCb.getValue();
        hospitalList.getItems().setAll(
                hospitals.stream()
                        .filter(hospital -> selectedFilter.equals("Tüm Hastaneler") || hospital.hasSpecialty(selectedFilter))
                        .sorted((h1, h2) -> Integer.compare(h2.getAmbulanceCount(), h1.getAmbulanceCount()))
                        .toList()
        );
    }

    private void resetHomeSelection() {
        selectedHome = null;
        selectedHomeLabel.setText("Seçili Değil");
        callAmbulanceBtn.setDisable(true);
        detailArea.clear();
        clearCanvasDrawings();
    }

    private void selectHomeForEmergency(Node home) {
        clearCanvasDrawings();
        selectedHome = home;
        selectedHomeLabel.setText(home.getDisplayName());
        callAmbulanceBtn.setDisable(false);
        highlightSelectedHome(home);
    }

    private void highlightSelectedHome(Node home) {
        System.out.println("🎯 Ev seçildi: " + home.getDisplayName());
    }

    @FXML
    private void onHospitalSelected() {
        Hospital selectedHospital = hospitalList.getSelectionModel().getSelectedItem();
        if (selectedHospital != null) {
            detailArea.setText(String.format("🏥 %s\n🚑 Ambulans: %d adet\n⚕️ Uzmanlık: %s",
                    selectedHospital.getName(), selectedHospital.getAmbulanceCount(),
                    String.join(", ", selectedHospital.getSpecialties())));
        }
    }

    @FXML
    private void onAmbulanceSelected() {
        String selectedMission = ambulanceList.getSelectionModel().getSelectedItem();
        if (selectedMission == null) return;

        Double remainingTime = ambulanceTimers.get(selectedMission);
        detailArea.setText(String.format("🚑 %s\n⏱️ Kalan Süre: %.1f dakika\n📍 Aktif görev detayları",
                selectedMission, remainingTime != null ? remainingTime : 0.0));

        List<Point2D> route = ambulanceRoutes.get(selectedMission);
        if (route != null && !route.isEmpty()) {
            clearCanvasDrawings();
            drawNavigationalRoute(canvas.getGraphicsContext2D(), route);
        }
    }

    @FXML
    private void dispatchEmergencyAmbulance() {
        if (selectedHome == null) {
            showNotification("❌ Lütfen önce bir ev seçin!");
            return;
        }

        clearCanvasDrawings();

        Hospital targetHospital = findOptimalHospital();
        if (targetHospital == null) {
            showAlert("Uygun hastane bulunamadı", "Seçilen durum için uygun bölümü olan hastane yok.");
            return;
        }

        Hospital dispatchHospital = findNearestAvailableAmbulance();
        if (dispatchHospital == null) {
            showAlert("Ambulans Yok", "Şu anda kullanılabilir ambulans bulunmuyor.");
            return;
        }

        executeEmergencyMission(dispatchHospital, targetHospital);
    }

    private Hospital findOptimalHospital() {
        String requiredSpecialty = getRequiredSpecialty(condCb.getValue());
        String selectedFilter = specFilterCb.getValue();

        Map<Node, Node> pathMap = new HashMap<>();
        Map<Node, Double> distances = graph.dijkstra(selectedHome, pathMap);

        return hospitals.stream()
                .filter(h -> selectedFilter.equals("Tüm Hastaneler") || h.hasSpecialty(selectedFilter))
                .filter(h -> h.hasSpecialty(requiredSpecialty))
                .min(Comparator.comparing(h -> distances.getOrDefault(h.getLocation(), Double.POSITIVE_INFINITY)))
                .orElse(null);
    }

    private Hospital findNearestAvailableAmbulance() {
        Map<Node, Node> pathMap = new HashMap<>();
        Map<Node, Double> distances = graph.dijkstra(selectedHome, pathMap);

        Hospital nearestHospital = hospitals.stream()
                .filter(Hospital::hasAvailableAmbulance)
                .min(Comparator.comparing(h -> distances.getOrDefault(h.getLocation(), Double.POSITIVE_INFINITY)))
                .orElse(null);

        if (nearestHospital != null) {
            System.out.println("🚑 En yakın ambulans: " + nearestHospital.getName());
        }

        return nearestHospital;
    }

    private String getRequiredSpecialty(String condition) {
        return switch (condition) {
            case "Kalp Krizi", "Hipertansif Kriz" -> "Kalp Cerrahi";
            case "Beyin Kanaması", "Epilepsi Nöbeti", "Migren Atağı", "Vertigo", "Panik Atak" -> "Nöroloji";
            case "Solunum Durması", "Akut Astım Krizi", "COVID-19 Ağır Seyir" -> "Göğüs Cerrahi";
            case "Şiddetli Kaza Travması", "Kemik Kırığı", "Yanık (2-3. Derece)", "Boyun Fıtığı" -> "Ortopedi";
            case "Akut Apandisit" -> "Göğüs Cerrahi";
            case "Doğum Komplikasyonu" -> "Çocuk Sağlığı";
            case "Anafılaktik Şok", "Şeker Koması", "Akut Gastrit", "Böbrek Taşı Koliği",
                 "Gıda Zehirlenmesi", "Alerjik Reaksiyon", "Akut Böbrek Yetmezliği", "Göz Travması" -> "Acil Tıp";
            case "Travma" -> "Travma";
            default -> "Acil Tıp";
        };
    }

    private void executeEmergencyMission(Hospital dispatchHospital, Hospital targetHospital) {
        PatientRecord patientRecord = patientRecords.get(selectedHome);
        String currentCondition = condCb.getValue();

        PatientRecord.Priority priority = patientRecord.calculateCurrentPriority(currentCondition);
        patientRecord.addEmergencyCall(currentCondition, targetHospital.getName(), LocalDateTime.now(), priority);

        deployGroundAmbulance(dispatchHospital, targetHospital, patientRecord, currentCondition);
    }

    private void deployGroundAmbulance(Hospital dispatchHospital, Hospital targetHospital, PatientRecord patient, String condition) {
        List<Point2D> missionRoute = calculateMissionRoute(dispatchHospital, targetHospital);
        double baseTime = calculateRouteTime(missionRoute);
        double totalMissionTime = baseTime * congestionSlider.getValue();

        String missionId = String.format("🚑 %s → %s", dispatchHospital.getName(), selectedHome.getDisplayName());

        MedicalStaffSystem.MedicalStaff assignedStaff = medicalStaffSystem.assignEmergencyStaff(dispatchHospital.getName(), condition);
        if (assignedStaff != null) {
            missionId += " (" + assignedStaff.getName() + ")";
        }

        dispatchHospital.dispatchAmbulance();
        updateHospitalListView();

        activeAmbulances.add(missionId);
        ambulanceTimers.put(missionId, totalMissionTime);
        ambulanceRoutes.put(missionId, missionRoute);

        startAmbulanceAnimation(missionRoute, totalMissionTime, missionId, dispatchHospital, targetHospital);

        totalEmergencies++;
        updateEmergencyStats();

        showNotification("🚑 Ambulans yola çıktı: " + missionId);
        statusLabel.setText(String.format("Aktif Görev: %s (%.1f dk)", missionId, totalMissionTime));

        if (sirenCb.isSelected() && sirenClip != null) {
            sirenClip.setFramePosition(0);
            sirenClip.loop(Clip.LOOP_CONTINUOUSLY);
        }
    }

    private List<Point2D> calculateMissionRoute(Hospital dispatchHospital, Hospital targetHospital) {
        List<Point2D> route = new ArrayList<>();

        Point2D dispatchPosition = nodeCoordinates.get(dispatchHospital.getLocation());
        route.add(dispatchPosition);
        System.out.println("🚑 Başlangıç: " + dispatchHospital.getName());

        Point2D homePosition = nodeCoordinates.get(selectedHome);
        route.add(homePosition);
        System.out.println("🏠 Hasta alınacak ev: " + selectedHome.getDisplayName());

        Point2D targetPosition = nodeCoordinates.get(targetHospital.getLocation());
        route.add(targetPosition);
        System.out.println("🏥 Final hedef hastane: " + targetHospital.getName());

        System.out.println("✅ Rota: " + dispatchHospital.getName() + " → " + selectedHome.getDisplayName() + " → " + targetHospital.getName());
        return route;
    }

    private double calculateRouteTime(List<Point2D> route) {
        double totalTime = 0;
        for (int i = 0; i < route.size() - 1; i++) {
            double segmentDistance = route.get(i).distance(route.get(i + 1));
            totalTime += (segmentDistance / 25.0) * congestionSlider.getValue();
        }
        return totalTime;
    }

    private void startAmbulanceAnimation(List<Point2D> route, double totalTime, String missionId, Hospital dispatchHospital, Hospital targetHospital) {
        Circle ambulanceMarker = new Circle(10, Color.RED);
        ambulanceMarker.setStyle("-fx-effect: dropshadow(gaussian, rgba(255,0,0,0.8), 15, 0.5, 0, 0);");
        mapPane.getChildren().add(ambulanceMarker);

        Timeline blinkTimeline = new Timeline(
                new KeyFrame(Duration.millis(300), e -> {
                    ambulanceMarker.setFill(Color.RED);
                    ambulanceMarker.setStyle("-fx-effect: dropshadow(gaussian, rgba(255,0,0,0.9), 20, 0.7, 0, 0);");
                }),
                new KeyFrame(Duration.millis(600), e -> {
                    ambulanceMarker.setFill(Color.BLUE);
                    ambulanceMarker.setStyle("-fx-effect: dropshadow(gaussian, rgba(0,0,255,0.9), 20, 0.7, 0, 0);");
                })
        );
        blinkTimeline.setCycleCount(Timeline.INDEFINITE);
        blinkTimeline.play();

        Path animationPath = createExactNavigationPath(route);

        PathTransition pathTransition = new PathTransition(Duration.seconds(totalTime), animationPath, ambulanceMarker);
        pathTransition.setInterpolator(Interpolator.LINEAR);
        pathTransition.rateProperty().bind(speedSlider.valueProperty());

        pathTransition.setOnFinished(event -> {
            blinkTimeline.stop();
            mapPane.getChildren().remove(ambulanceMarker);
            activeAmbulances.remove(missionId);
            completedMissions.add(missionId + " ✅");
            ambulanceTimers.remove(missionId);

            redistributeAmbulance(dispatchHospital, targetHospital);
            updateHospitalListView();
            completedEmergencies++;
            updateEmergencyStats();

            statusLabel.setText("Görev Tamamlandı: " + missionId);
            showNotification("✅ Hasta hastaneye ulaştırıldı!");

            if (sirenClip != null && sirenClip.isRunning()) {
                sirenClip.stop();
            }
        });

        pathTransition.play();
        drawNavigationalRoute(canvas.getGraphicsContext2D(), route);
    }

    private void redistributeAmbulance(Hospital dispatchHospital, Hospital targetHospital) {
        if (dispatchHospital.equals(targetHospital)) {
            dispatchHospital.returnAmbulance();
            System.out.println("🚑 Ambulans " + dispatchHospital.getName() + " hastanesine döndü");
        } else {
            targetHospital.returnAmbulance();
            System.out.println("🚑 Ambulans " + targetHospital.getName() + " hastanesinde kaldı");
        }
    }

    private Path createExactNavigationPath(List<Point2D> route) {
        Path path = new Path();
        if (route.size() < 2) return path;

        // Basit scale - tam pane boyutuna göre
        double scaleX = actualMapWidth / 900.0;
        double scaleY = actualMapHeight / 600.0;

        // Offset yok
        double offsetX = 0;
        double offsetY = 0;

        Point2D firstPoint = route.get(0);
        double startX = firstPoint.getX() * scaleX;
        double startY = firstPoint.getY() * scaleY;
        path.getElements().add(new MoveTo(startX, startY));

        for (int i = 1; i < route.size(); i++) {
            Point2D current = route.get(i - 1);
            Point2D next = route.get(i);

            double currentX = current.getX() * scaleX;
            double currentY = current.getY() * scaleY;
            double nextX = next.getX() * scaleX;
            double nextY = next.getY() * scaleY;

            double midX, midY;

            if (Math.abs(nextX - currentX) > Math.abs(nextY - currentY)) {
                midX = nextX;
                midY = currentY;
            } else {
                midX = currentX;
                midY = nextY;
            }

            path.getElements().add(new LineTo(midX, midY));
            path.getElements().add(new LineTo(nextX, nextY));
        }

        System.out.println("🛣️ Ambulans path TAM BOYUT için oluşturuldu");
        return path;
    }

    private void drawNavigationalRoute(GraphicsContext gc, List<Point2D> route) {
        if (route.size() < 2) return;

        // Basit scale - tam pane boyutuna göre
        double scaleX = actualMapWidth / 900.0;
        double scaleY = actualMapHeight / 600.0;

        // Offset yok
        double offsetX = 0;
        double offsetY = 0;

        gc.setStroke(Color.DODGERBLUE);
        gc.setLineWidth(4);

        for (int i = 0; i < route.size() - 1; i++) {
            Point2D current = route.get(i);
            Point2D next = route.get(i + 1);

            double currentX = current.getX() * scaleX;
            double currentY = current.getY() * scaleY;
            double nextX = next.getX() * scaleX;
            double nextY = next.getY() * scaleY;

            drawNavigationSegment(gc, currentX, currentY, nextX, nextY);
        }
    }

    private void drawNavigationSegment(GraphicsContext gc, double x1, double y1, double x2, double y2) {
        double midX, midY;

        if (Math.abs(x2 - x1) > Math.abs(y2 - y1)) {
            midX = x2;
            midY = y1;
        } else {
            midX = x1;
            midY = y2;
        }

        gc.beginPath();
        gc.moveTo(x1, y1);
        gc.lineTo(midX, midY);
        gc.lineTo(x2, y2);
        gc.stroke();

        drawDirectionArrow(gc, x1, y1, midX, midY);
        drawDirectionArrow(gc, midX, midY, x2, y2);
    }

    private void drawDirectionArrow(GraphicsContext gc, double x1, double y1, double x2, double y2) {
        double arrowLength = 10;
        double arrowAngle = Math.PI / 6;
        double angle = Math.atan2(y2 - y1, x2 - x1);
        double midX = (x1 + x2) / 2;
        double midY = (y1 + y2) / 2;

        double arrowX1 = midX - arrowLength * Math.cos(angle - arrowAngle);
        double arrowY1 = midY - arrowLength * Math.sin(angle - arrowAngle);
        double arrowX2 = midX - arrowLength * Math.cos(angle + arrowAngle);
        double arrowY2 = midY - arrowLength * Math.sin(angle + arrowAngle);

        gc.strokeLine(midX, midY, arrowX1, arrowY1);
        gc.strokeLine(midX, midY, arrowX2, arrowY2);
    }

    private void updateEmergencyStats() {
        if (emergencyBar != null && emergencyCountLabel != null) {
            double progress = totalEmergencies == 0 ? 0.0 : (double) completedEmergencies / totalEmergencies;
            emergencyBar.setProgress(progress);
            emergencyCountLabel.setText(String.format("%d/%d Acil Durum", completedEmergencies, totalEmergencies));
        }
    }

    private void clearCanvasDrawings() {
        GraphicsContext gc = canvas.getGraphicsContext2D();
        gc.clearRect(0, 0, canvas.getWidth(), canvas.getHeight());
    }

    private void showNotification(String message) {
        Label notification = new Label(message);
        notification.setStyle("-fx-background-color: rgba(76, 175, 80, 0.9); -fx-text-fill: white; -fx-padding: 12px 20px; -fx-background-radius: 8px; -fx-font-size: 14px; -fx-font-weight: bold;");

        toastPane.getChildren().add(notification);
        StackPane.setAlignment(notification, javafx.geometry.Pos.TOP_CENTER);

        FadeTransition fadeIn = new FadeTransition(Duration.millis(300), notification);
        fadeIn.setFromValue(0);
        fadeIn.setToValue(1);

        PauseTransition pause = new PauseTransition(Duration.seconds(3));

        FadeTransition fadeOut = new FadeTransition(Duration.millis(500), notification);
        fadeOut.setFromValue(1);
        fadeOut.setToValue(0);

        SequentialTransition sequence = new SequentialTransition(fadeIn, pause, fadeOut);
        sequence.setOnFinished(e -> toastPane.getChildren().remove(notification));
        sequence.play();
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}