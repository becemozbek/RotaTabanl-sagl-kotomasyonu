package com.example.otomasyonn;

import java.util.List;

/**
 * Hastane bilgileri - lokasyon, uzmanlık bölümleri ve ambulans sayısı
 */
public class Hospital {
    private final String name;
    private final Node location;
    private final List<String> specialties;
    private int ambulanceCount;
    private final int capacity; // Yatak kapasitesi
    private final HospitalType type;

    public enum HospitalType {
        STATE("Devlet Hastanesi", "🏥"),
        PRIVATE("Özel Hastane", "🏨"),
        UNIVERSITY("Üniversite Hastanesi", "🎓"),
        EMERGENCY("Acil Tıp Merkezi", "🚑");

        private final String displayName;
        private final String icon;

        HospitalType(String displayName, String icon) {
            this.displayName = displayName;
            this.icon = icon;
        }

        public String getDisplayName() { return displayName; }
        public String getIcon() { return icon; }
    }

    public Hospital(String name, Node location, List<String> specialties) {
        this(name, location, specialties, HospitalType.STATE, 100);
    }

    public Hospital(String name, Node location, List<String> specialties, HospitalType type, int capacity) {
        this.name = name;
        this.location = location;
        this.specialties = specialties;
        this.type = type;
        this.capacity = capacity;
        this.ambulanceCount = 2; // Varsayılan ambulans sayısı
    }

    public String getName() {
        return name;
    }

    public Node getLocation() {
        return location;
    }

    public List<String> getSpecs() {
        return specialties;
    }

    public List<String> getSpecialties() {
        return specialties;
    }

    public int getAmbulanceCount() {
        return ambulanceCount;
    }

    public void setAmbulanceCount(int ambulanceCount) {
        this.ambulanceCount = Math.max(0, ambulanceCount);
    }

    public int getCapacity() {
        return capacity;
    }

    public HospitalType getType() {
        return type;
    }

    public String getFullDisplayName() {
        return String.format("%s %s (%d amb. - %s)",
                type.getIcon(), name, ambulanceCount, type.getDisplayName());
    }

    public boolean hasSpecialty(String specialty) {
        return specialties.contains(specialty);
    }

    public boolean hasAvailableAmbulance() {
        return ambulanceCount > 0;
    }

    public void dispatchAmbulance() {
        if (ambulanceCount > 0) {
            ambulanceCount--;
        }
    }

    public void returnAmbulance() {
        ambulanceCount++;
    }

    @Override
    public String toString() {
        return String.format("%s (%d amb.) - %s",
                name, ambulanceCount, String.join(", ", specialties));
    }
}