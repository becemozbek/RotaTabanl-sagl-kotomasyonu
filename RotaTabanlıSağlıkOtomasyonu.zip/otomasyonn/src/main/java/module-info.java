module com.example.otomasyonn {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.desktop;            // javax.sound için
    opens com.example.otomasyonn
            to javafx.fxml;
    exports com.example.otomasyonn;
}
